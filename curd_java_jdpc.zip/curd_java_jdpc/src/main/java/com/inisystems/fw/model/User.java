package com.inisystems.fw.model;
import com.inisystems.fw.model.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private Long id;

    private String username;

    private String firstname;

    private String lastname;

    private String email;



    private String password;



    Role role;



    boolean isActive;



}
