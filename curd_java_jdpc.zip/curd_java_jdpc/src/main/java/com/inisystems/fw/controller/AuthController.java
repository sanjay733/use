package com.inisystems.fw.controller;



import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.service.UserService;
import com.inisystems.fw.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
@RequestMapping("/public")
public class AuthController {

    private final UserService userService;


    @GetMapping("/login")
    public String login() {
        // Your logic for the login page
        return "login";
    }


    @PostMapping("/auth")
    public String processLogin(Model model, HttpServletRequest request) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            User user = userService.authenticateUser(username, password);
            String accessToken = JwtUtil.generateToken(username, user.getRole());

            model.addAttribute("username", user.getUsername());
            model.addAttribute("accessToken", accessToken);

            return "/home";
        } catch (UserNotFoundException e) {
            model.addAttribute("error", "User not found");
            return "login";
        } catch (AuthenticationException e) {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        } catch (Exception e) {
            // Handle other exceptions
            model.addAttribute("error", "An unexpected error occurred");
            return "error";
        }
    }



}
