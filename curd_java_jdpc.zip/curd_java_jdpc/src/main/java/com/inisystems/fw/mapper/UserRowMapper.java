package com.inisystems.fw.mapper;

import com.inisystems.fw.model.enums.Role;
import com.inisystems.fw.model.User;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRowMapper implements RowMapper<User> {

    @Override
    public User mapRow(ResultSet rs, int rowNum) throws SQLException {
        return User.builder()
                .id(rs.getLong("id"))
                .username(rs.getString("username"))
                .firstname(rs.getString("firstname"))
                .lastname(rs.getString("lastname"))
                .email(rs.getString("email"))
                .password(rs.getString("password"))
                 .role(Role.valueOf(rs.getString("role")))
                      .isActive(rs.getBoolean("is_active"))
                .build();
    }
}
