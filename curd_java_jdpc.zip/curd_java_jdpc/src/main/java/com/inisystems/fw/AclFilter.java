package com.inisystems.fw;

import com.inisystems.fw.utils.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class AclFilter extends OncePerRequestFilter {
    Logger log= LoggerFactory.getLogger("AclFilter");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {



            String requestURI = request.getRequestURI();

            // Check if the request path starts with /secure/
            if (requestURI.startsWith("/api/secure/")) {
                String authorizationHeader = request.getHeader("Authorization");

                if(authorizationHeader==null && request.getParameter("token")!=null ){
                     authorizationHeader=request.getParameter("token");

                }
                if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
                    String token = authorizationHeader.substring(7); // Extract the token from the Authorization header
                    try {
                        if (JwtUtil.validateToken(token)) {
                            String username = JwtUtil.extractUsername(token);
                            String role = JwtUtil.extractClaims(token).get("role", String.class);

                            request.setAttribute("username", username);
                            request.setAttribute("role", role);
                        } else {
                            // Token validation failed, send a 401 Unauthorized response
                            log.warn("Token validation failed: {}", token);

                            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                            response.getWriter().write("Unauthorized: Token validation failed");
                            return;
                        }
                    } catch (Exception e) {
                        // Token validation failed, send a 401 Unauthorized response
                        log.warn("Token validation error: {} {}", e.getMessage(), token);
                        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        response.getWriter().write("Unauthorized: Token validation error");
                        return;
                    }
                } else {
                    // Token validation failed, send a 401 Unauthorized response
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    response.getWriter().write("Unauthorized: Invalid token format");
                    return;
                }
            }
            // Continue with the request chain
            filterChain.doFilter(request, response);

    }
}
