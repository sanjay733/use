package com.inisystems.fw.utils;

import com.kosprov.jargon2.api.Jargon2;

public class HashUtils {
    public static boolean verifyHash(String password, String encodedHash) {
        Jargon2.Verifier verifier = Jargon2.jargon2Verifier();
        // Set the encoded hash, the password and verify
        return verifier.hash(encodedHash).password(password.getBytes()).verifyEncoded();
    }

    public static boolean verifyPassword(String password, String dbPassword) {
        return password.equals(password);
    }


    public static String generateEncodedHash(String password) {
        Jargon2.Hasher hasher = Jargon2.jargon2Hasher()
                .type(Jargon2.Type.ARGON2d) // Data-dependent hashing
                .memoryCost(65536)  // 64MB memory cost
                .timeCost(3)        // 3 passes through memory
                .parallelism(4)     // use 4 lanes and 4 threads
                .saltLength(16)     // 16 random bytes salt
                .hashLength(16);    // 16 bytes output hash
        // Set the password and calculate the encoded hash
        return hasher.password(password.getBytes()).encodedHash();

    }
}
