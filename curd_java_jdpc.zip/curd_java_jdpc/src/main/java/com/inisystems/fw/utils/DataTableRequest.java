package com.inisystems.fw.utils;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataTableRequest {
    int seq;
    int page;
    int pageSize;
    String sortBy;
    String sortDirection;
    String filter;


}
