package com.inisystems.fw.model.enums;

public enum ResponseStatus {
    success,

    error,
    failed;
}
