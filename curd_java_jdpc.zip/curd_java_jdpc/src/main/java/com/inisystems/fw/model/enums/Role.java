package com.inisystems.fw.model.enums;

public enum Role {
    ADMIN, USER;
}
