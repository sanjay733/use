package com.inisystems.fw.utils;

import com.inisystems.fw.model.enums.Role;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtUtil {

    private static final String SECRET_KEY = "HCjFQbDUb6uZsDeDqtCJgnfwIr5xoMSs2aoP8Pt9aVo=";
    long oneWeekInMillis = 7 * 24 * 60 * 60 * 1000; // 7 days * 24 hours * 60 minutes * 60 seconds * 1000 milliseconds

    public static String generateToken(String username, Role role) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(username)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                //.setExpiration(new Date(System.currentTimeMillis() + 10 * 1000)) // Token valid for 10 seconds
                //.setExpiration(new Date(System.currentTimeMillis() + 60 * 1000)) // Token valid for 60 seconds (1 minute)
                //.setExpiration(new Date(System.currentTimeMillis() + 10 * 60 * 1000)) // Token valid for 10 minutes
                //.setExpiration(new Date(System.currentTimeMillis() + 1 * 60 * 60 *1000)) // Token valid for 1 hour
                //.setExpiration(new Date(System.currentTimeMillis() + 10 * 60 * 60 * 1000)) // Token valid for 10 hour
                .setExpiration(new Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 *1000 )) // Token valid for 1 week

                .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
                .compact();
    }

    public static String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    public static Claims extractClaims(String token) {
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }

    public static boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    //dont generate every time
    public static String generateKey(){
        SecureRandom secureRandom = new SecureRandom();
        byte[] keyBytes = new byte[32]; // 256 bits / 8 = 32 bytes
        secureRandom.nextBytes(keyBytes);

        // Encode the random byte array to Base64 to obtain a string representation of the secret key
        String secretKey = Base64.getEncoder().encodeToString(keyBytes);

        System.out.println("Generated Secret Key: " + secretKey);
        return  secretKey;
    }

    public static void main(String[] args) {
        generateKey();
    }
}

