package com.inisystems.fw.repo;

import com.inisystems.fw.mapper.UserRowMapper;
import com.inisystems.fw.model.User;
import com.inisystems.fw.utils.FwUtils;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
@AllArgsConstructor
public class UserRepository {

   // private final JdbcTemplate jdbcTemplate;
   // private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;




    private final JdbcTemplate jdbcTemplate;

    private final NamedParameterJdbcTemplate npJdbcTemplate;







    public User saveUser(User user) {
        Timestamp currentTimestamp = FwUtils.getCurrentTimestamp();
        String insertUserQuery = "INSERT INTO users (username, firstname, lastname, email, password" +
                ", role,  is_active) " +
                "VALUES (:username, :firstname, :lastname, :email, :password,  :role, :is_active)";


        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
        parameterSource.addValue("username", user.getUsername());
        parameterSource.addValue("firstname", user.getFirstname());
        parameterSource.addValue("lastname", user.getLastname());
        parameterSource.addValue("email", user.getEmail());
        parameterSource.addValue("password", user.getPassword());

        parameterSource.addValue("role", user.getRole().name());

        parameterSource.addValue("is_active", user.isActive());


        KeyHolder keyHolder = new GeneratedKeyHolder();

       // npJdbcTemplate.update(insertUserQuery, parameterSource, keyHolder);
        npJdbcTemplate.update(insertUserQuery, parameterSource, keyHolder, new String[]{"id"}); // Specify the name of the generated key column



        Number generatedId = keyHolder.getKey();

        if (generatedId != null) {
            user.setId(generatedId.longValue());
        }

        return user;
    }


    public List<User> findAllUsers() {
        String selectAllUsersQuery = "SELECT * FROM users";
        return jdbcTemplate.query(selectAllUsersQuery, new UserRowMapper());
    }

    public User findByUserId(Long id) {
        String selectUserQuery = "SELECT * FROM users WHERE id = ?";
        try {
            return jdbcTemplate.queryForObject(selectUserQuery, new UserRowMapper(), id);
        } catch (EmptyResultDataAccessException e) {
            // Handle the case where no records are found
            return null;
        }
    }

    public User findByUsername(String username) {
        String selectUserQuery = "SELECT * FROM users WHERE username = ?";
        try {
            return jdbcTemplate.queryForObject(selectUserQuery, new UserRowMapper(), username);
        } catch (EmptyResultDataAccessException e) {
            // Handle the case where no records are found
            return null;
        }
    }

    public boolean existsByUsername1(String username) {
        String selectUserQuery = "SELECT COUNT(*) FROM users WHERE username = ?";
        int count = jdbcTemplate.queryForObject(selectUserQuery, Integer.class, username);
        return count > 0;
    }

    public boolean existsByUsername(String username) {
        String selectUserQuery = "SELECT COUNT(*) FROM users WHERE LOWER(username) = LOWER(?)";
        int count = jdbcTemplate.queryForObject(selectUserQuery, Integer.class, username.toLowerCase());
        return count > 0;
    }

    public boolean existsByEmail(String email) {
        String selectUserQuery = "SELECT COUNT(*) FROM users WHERE LOWER(email) = LOWER(?)";
        int count = jdbcTemplate.queryForObject(selectUserQuery, Integer.class, email.toLowerCase());
        return count > 0;
    }





    public Page<User> getUserPagination(String filterValue, PageRequest pageRequest) {
        // Construct the base SQL query
        StringBuilder sql = new StringBuilder("SELECT * FROM users WHERE 1 = 1");

        // Add filter conditions based on filterValue
        if (filterValue != null && !filterValue.isEmpty()) {
            sql.append(" AND (username LIKE :filterValue OR firstname LIKE :filterValue OR email LIKE :filterValue)");
        }

        // Exclude admin records
        String exclusionCondition = "role != 'ADMIN'";
        sql.append(" AND ").append(exclusionCondition);

        // Add sorting condition based on pageRequest
        Sort sort = pageRequest.getSort();
        if (sort != null) {
            sql.append(" ORDER BY ");
            sort.forEach(order -> {
                sql.append(order.getProperty());
                if (order.getDirection() == Sort.Direction.DESC) {
                    sql.append(" DESC");
                } else {
                    sql.append(" ASC");
                }
                sql.append(", ");
            });
            // Remove the trailing comma
            sql.delete(sql.length() - 2, sql.length());
        }

        // Add pagination conditions
        sql.append(" LIMIT :pageSize OFFSET :offset");

        // Create parameter source for named parameters
        MapSqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("filterValue", "%" + filterValue + "%")  // Add wildcards for partial match
                .addValue("pageSize", pageRequest.getPageSize())
                .addValue("offset", pageRequest.getOffset());

        // Execute the query and return the result as a Page
        List<User> userList = npJdbcTemplate.query(sql.toString(), namedParameters, new UserRowMapper());

        return PageableExecutionUtils.getPage(userList, pageRequest, () -> {
            // Count query to determine the total count for pagination
            String countSql = "SELECT COUNT(*) FROM users WHERE 1 = 1";
            if (filterValue != null && !filterValue.isEmpty()) {
                countSql += " AND (username LIKE :filterValue OR firstname LIKE :filterValue OR email LIKE :filterValue)";
            }

            countSql += " AND " + exclusionCondition;

            Long totalCount = npJdbcTemplate.queryForObject(countSql, namedParameters, Long.class);
            return totalCount;
        });
    }




    public void updateTokenByUsername(String username, String newAccessToken, String newRefreshToken) {
        String updateTokenQuery = "UPDATE users SET token = ? , refresh_token = ? WHERE username = ?";

        jdbcTemplate.update(updateTokenQuery, newAccessToken, newRefreshToken, username);
    }

    public void updateLastloginByUsername(String username) {
        String updateTokenQuery = "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE username = ?";

        jdbcTemplate.update(updateTokenQuery, username);
    }




}
