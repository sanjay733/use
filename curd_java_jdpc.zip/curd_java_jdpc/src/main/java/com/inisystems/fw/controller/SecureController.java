package com.inisystems.fw.controller;



import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.service.UserService;
import com.inisystems.fw.utils.ApiResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/secure")
public class SecureController {

    private final UserService userService;

    @GetMapping("/getalluser")
    public List<User> getAllUsers() {

        return  userService.findAllUsers();
    }



    @PostMapping("/getuser/{username}")
    public ResponseEntity<Object> getUserByUsername(@PathVariable String username) {
        try {
            User user = userService.findByUsername(username);
            return ResponseEntity.ok(user);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
        }
    }


}
