package com.inisystems.fw.utils;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.sql.Timestamp;
import java.util.List;

public class FwUtils {


    public static Timestamp getCurrentTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    public static <T> DataTableResponse<T> buildDataTableResponse(Page<T> page) {
        DataTableResponse<T> response = new DataTableResponse<>(
                page.getContent(),
                page.getNumber() + 1,
                page.getTotalPages(),
                page.getTotalElements()
        );

        return response;
    }

    public static <T> Page<T> convertListToDTOPage(List<T> content, Pageable pageable, long totalElements) {
        return new PageImpl<>(content, pageable, totalElements);
    }



}
