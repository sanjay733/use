package com.inisystems.fw.service;



import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.repo.UserRepository;
import com.inisystems.fw.utils.*;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UserService {
    static Logger LOGGER = LoggerFactory.getLogger("UserService");
    private final UserRepository userRepository;



    public User findByUsername(String username) {
        User user = userRepository.findByUsername(username);

        if (user != null) {
            return user;
        } else {
            throw new UserNotFoundException("User not found with username: " + username);
        }
    }

    public User authenticateUser(String username, String password) {

        User user = userRepository.findByUsername(username);


        if (user != null && password.equals(user.getPassword())) {
            return user;
        } else {
            throw new AuthenticationException("Invalid username or password");
        }
    }
    public List<User> findAllUsers(){

        return userRepository.findAllUsers();
    }
}

