package com.inisystems.fw.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.Project;
import com.inisystems.fw.model.Tracker;
import com.inisystems.fw.model.User;
import com.inisystems.fw.repo.TrackerRepository;
import com.inisystems.fw.repo.UserRepository;

@Service
public class TrackerService {
	  static Logger LOGGER = LoggerFactory.getLogger("UserService");
	    private final TrackerRepository trackerRepository;



	    public TrackerService(TrackerRepository trackerRepository) {
			super();
			this.trackerRepository = trackerRepository;
		}
	    
	    
	    public void saveWork(Long project_id,String project_name,
	    		int hours_worked,String date,Long user_id,String task,String comments) 
	    	{
	    		Tracker tracker=new Tracker();
	    		tracker.setProject_name(project_name);
	    		tracker.setTask(task);
	    		tracker.setActive(true);
	    		tracker.setComments(comments);
	    		tracker.setProject_id(project_id);
	    		tracker.setUser_id(user_id);
	    		tracker.setDate(date);
	    		tracker.setWorkedHours(hours_worked);
	    		
	    		trackerRepository.saveTracker(tracker);
	    	}
	    
	    public void updateWork(Long id, String date, int hours_worked, String comments) {
	        Tracker tracker = new Tracker();
	        tracker.setId(id);
	        tracker.setDate(date);
	        tracker.setWorkedHours(hours_worked);
	        tracker.setComments(comments);
	        tracker.setActive(true);

	        trackerRepository.updateTracker(tracker);
	    }
	    
	    public void updateTrackerStatus(Long trackerId, boolean status) {
	     
	    }

	    public void deleteWork(Long id) {
	        trackerRepository.deleteTracker(id);
	    }
      
	    public List<Tracker> findAllWorks(User user){
	        return trackerRepository.findAllWorks(user.getId());
	    }
	    
	    public List<Tracker> findWeekly(User user){
	        return trackerRepository.findWeekly(user.getId());
	    }
	    public List<Tracker> findMonthly(User user){
	        return trackerRepository.findMonthly(user.getId());
	    }
	    
	}


