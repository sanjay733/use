package com.inisystems.fw.controller;

import java.util.List;
import java.util.Map;

import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.time.LocalDateTime; 
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inisystems.fw.model.Project;
import com.inisystems.fw.model.User;
import com.inisystems.fw.service.UserService;
import com.inisystems.fw.service.ProjectService;

 
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/secure/dashboard")
public class ProjectController {
	
	@Autowired
    private final UserService userService;
   
    @Autowired
    private final ProjectService projectService;
   
    String date=java.time.LocalDate.now().toString();
   // String userEmail="john@example.com";
    
    
    public ProjectController(UserService userService, ProjectService projectService) {
        this.userService = userService;
        this.projectService = projectService;
    }
       
    private User  getUser(String email) {
    	User user=userService.findByEmail(email);
    return user;
    }

	 @PostMapping("/saveProject")
	    public ResponseEntity<?> saveProject(@RequestBody Map<String, Object> requestBody,HttpServletRequest req) {
		 
		   String email=(String)req.getAttribute("email");
		 User user=getUser(email);
	    	  String projectName=requestBody.get("projectname").toString();
	    	    String description=requestBody.get("description").toString();  
	    	   String hours_capacity_str=requestBody.get("hourscapacity").toString();
	    	   int hours_capacity=Integer.parseInt(hours_capacity_str);
	    	    try {
	    	      projectService.saveProject(description,projectName,hours_capacity,user.getId(),date,user.getFirstname());
	    	        return ResponseEntity.ok("project saved successfully");
	    	    } catch (Exception e) {        // Handle other exceptions
	    	        return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred");    }
	    	}
	 
	 
	 
	 
	   @PostMapping("/getProjectList")
	    	public ResponseEntity<?> getProjectList(HttpServletRequest req) {
		   String email=(String)req.getAttribute("email");
		 //  String email="john@example.com";
			 User user=getUser(email);
	    	       List<Project> projectList=projectService.findAllProject(user);
	    	        return ResponseEntity.ok().body(projectList);
	    	    
	    }
}