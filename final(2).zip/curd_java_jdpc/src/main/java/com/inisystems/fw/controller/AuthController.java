package com.inisystems.fw.controller;



import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.service.UserService;
import com.inisystems.fw.utils.JwtUtil;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/public")
public class AuthController {

    private final UserService userService;




    	@PostMapping("/getUserlist")
    	public ResponseEntity<?> getUserList() {

    	       List<User> userList=userService.findAllUsers();
    	        return ResponseEntity.ok().body(userList);
    	        // Handle other exceptions        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
    	    
    }

    @PostMapping("/auth_old")
    public String processLogin(Model model, HttpServletRequest request) {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            User user = userService.authenticateUser(email, password);
            String accessToken = JwtUtil.generateToken(email);
            model.addAttribute("username", user.getEmail());
            model.addAttribute("accessToken", accessToken);

            return "/dashboard";
        } catch (UserNotFoundException e) {
        	System.out.println(e);
            model.addAttribute("error", "User not found");
            return "login";
        } catch (AuthenticationException e) {
        	System.out.println(e);
            model.addAttribute("error", "Invalid email or password");
            return "login";
        } catch (Exception e) {
            // Handle other exceptions
        	System.out.println(e);
            model.addAttribute("error", "An unexpected error occurred");
            return "error";
        }
    }

    @PostMapping("/auth")public ResponseEntity<?> auth(@RequestBody Map<String, Object> requestBody) {
        String username=requestBody.get("username").toString();
        String password=requestBody.get("password").toString();

        try {
            User user = userService.authenticateUser(username, password);        String accessToken = JwtUtil.generateToken(username);
            Map<String,String> result=new HashMap<>();
            result.put("accessToken",accessToken);
            return ResponseEntity.ok(result);    } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("User not found");    } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("Invalid username or password");
        } catch (Exception e) {        // Handle other exceptions
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred");    }
    }

}
