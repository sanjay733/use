package com.inisystems.fw.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class PathController {
	@RequestMapping("/public/login")
	public String pageLoad() {
		return "login";
	}

	@RequestMapping("/public/dashboard")
	public String pageLoad1() {
		return "dashboard";
	}@RequestMapping("/public/tracker")
	public String pageLoad2() {
		return "tracker";
	}@RequestMapping("/public/work")
	public String pageLoad3() {
		return "work";
	}
@RequestMapping("/public/tracking")
public String pageLoad4() {
	return "trackers";
}
	

}
