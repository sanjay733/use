package com.inisystems.fw.utils;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class DataTableResponse<T> {
    private List<?> object;
    private int currentPage;
    private int totalPages;
    private long totalRecords;


    public DataTableResponse(List<?> object, int currentPage, int totalPages, long totalRecords) {
        this.object = object;
        this.currentPage = currentPage;
        this.totalPages = totalPages;
        this.totalRecords = totalRecords;
    }


    @Override
    public String toString() {
        return "DataTableResponse{" +
                "object=" + object +
                ", currentPage=" + currentPage +
                ", totalPages=" + totalPages +
                ", totalRecords=" + totalRecords +
                '}';
    }
}

