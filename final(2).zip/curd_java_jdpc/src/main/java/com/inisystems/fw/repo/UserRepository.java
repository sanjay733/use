package com.inisystems.fw.repo;

import com.inisystems.fw.mapper.UserRowMapper;
import com.inisystems.fw.model.User;
import com.inisystems.fw.utils.FwUtils;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository

public class UserRepository {

   // private final JdbcTemplate jdbcTemplate;
   // private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final JdbcTemplate jdbcTemplate;

    private final NamedParameterJdbcTemplate npJdbcTemplate;

   


    public UserRepository(JdbcTemplate jdbcTemplate, NamedParameterJdbcTemplate npJdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
		this.npJdbcTemplate = npJdbcTemplate;
	}

//    public User saveUser(User user) {
//        Timestamp currentTimestamp = FwUtils.getCurrentTimestamp();
//        String insertUserQuery = "INSERT INTO user (firstname, lastname, email, password, is_active) " +
//                "VALUES (:firstname, :lastname, :email, :password, :status)";
//
//        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
//        parameterSource.addValue("firstname", user.getFirstname());
//        parameterSource.addValue("lastname", user.getLastname());
//        parameterSource.addValue("email", user.getEmail());
//        parameterSource.addValue("password", user.getPassword());
//        parameterSource.addValue("status", true);  // Assuming 'status' is the correct field name
//
//        KeyHolder keyHolder = new GeneratedKeyHolder();
//
//        npJdbcTemplate.update(insertUserQuery, parameterSource, keyHolder, new String[]{"id"}); // Specify the name of the generated key column
//
//        Number generatedId = keyHolder.getKey();
//
//        if (generatedId != null) {
//            user.setId(generatedId.longValue());
//        }
//
//        return user;
//    }


	public List<User> findAllUsers() {
        String selectAllUsersQuery = "SELECT * FROM user";
        return jdbcTemplate.query(selectAllUsersQuery, new UserRowMapper());
        
    }

    public User findByUserId(Long id) {
        String selectUserQuery = "SELECT * FROM user WHERE id = ?";
        try {
            return jdbcTemplate.queryForObject(selectUserQuery, new UserRowMapper(), id);
        } catch (EmptyResultDataAccessException e) {
            // Handle the case where no records are found
            return null;
        }
    }

    public User findByEmail(String email) {
        String selectUserQuery = "SELECT * FROM user WHERE email = ?";
        try {
            return jdbcTemplate.queryForObject(selectUserQuery, new UserRowMapper(), email);
        } catch (EmptyResultDataAccessException e) {
            // Handle the case where no records are found
            return null;
        }
    }


    public boolean existsByEmail(String email) {
        String selectUserQuery = "SELECT COUNT(*) FROM user WHERE LOWER(email) = LOWER(?)";
        int count = jdbcTemplate.queryForObject(selectUserQuery, Integer.class, email.toLowerCase());
        return count > 0;
    }




    public void updateTokenByEmail(String email, String newAccessToken, String newRefreshToken) {
        String updateTokenQuery = "UPDATE users SET token = ? , refresh_token = ? WHERE username = ?";

        jdbcTemplate.update(updateTokenQuery, newAccessToken, newRefreshToken, email);
    }

    public void updateLastloginByUsername(String username) {
        String updateTokenQuery = "UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE username = ?";

        jdbcTemplate.update(updateTokenQuery, username);
    }


}
