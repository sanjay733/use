package com.inisystems.fw.mapper;

import com.inisystems.fw.model.Project;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProjectRowMapper implements RowMapper<Project> {

    @Override
    public Project mapRow(ResultSet rs, int rowNum) throws SQLException {
        return Project.builder()
                .id(rs.getLong("id"))
                .description(rs.getString("description"))
                .name(rs.getString("name"))
                .hours_capacity(rs.getInt("hours_capacity"))
                .user_id(rs.getLong("user_id"))
                .modified_date(rs.getString("modified_date"))
                .modified_by(rs.getString("modified_by"))
                .is_active(rs.getBoolean("is_active"))
                .build();
    }
}
