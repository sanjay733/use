package com.inisystems.fw.mapper;

import com.inisystems.fw.model.enums.Role;
import com.inisystems.fw.model.User;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRowMapper implements RowMapper<User> {

    @Override
    public User mapRow(ResultSet rs, int rowNum) throws SQLException {
        return User.builder()
                .id(rs.getLong("id"))
                .firstname(rs.getString("firstname"))
                .lastname(rs.getString("lastname"))
                .email(rs.getString("email"))
                .password(rs.getString("password"))
                      .status(rs.getBoolean("status"))
                .build();
    }
}
