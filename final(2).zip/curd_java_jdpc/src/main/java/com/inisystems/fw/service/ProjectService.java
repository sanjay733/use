package com.inisystems.fw.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.Project;
import com.inisystems.fw.model.User;
import com.inisystems.fw.repo.ProjectRepository;
import com.inisystems.fw.repo.UserRepository;

import io.swagger.v3.oas.annotations.servers.Server;

@Service
public class ProjectService {

    static Logger LOGGER = LoggerFactory.getLogger("UserService");
    private final ProjectRepository projectRepository;

    public ProjectService(ProjectRepository projectRepository) {
		super();
		this.projectRepository = projectRepository;
	}
    
    

    public void saveProject(String description,String projectName,int hours_capacity,Long id,String date,String user_name) 
    	{
    		
    		Project project = new Project();
    		project.setDescription(description);
    		project.setName(projectName);
    		project.setUser_id(id);
    		project.setModified_by(user_name);
    		project.setModified_date(date);
    		project.setHours_capacity(hours_capacity);
    		project.set_active(true);
    		
    		projectRepository.saveProject(project);
    	}

	
    public List<Project> findAllProject(User user){
        return projectRepository.findProjectsByUserId(user.getId());
    }
    
    public Project findByUserId(Long userId) {
        return projectRepository.findByUserId(userId);
    }
    
    
    public Project getProjectName(Long projId) {
        return projectRepository.findProjectName(projId);
    }
}
