package com.inisystems.fw.model;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Project {
	 
	
    
    private Long id;    
    
    private String description;
    
    private String name;
    
    private int hours_capacity;
    
    private Long user_id;
    
    private String modified_date;
    
    private String modified_by;

    private boolean is_active;
    
//    public Long getId() {
//        return id;
//    }
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getName() {
//        return name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public int getHoursCapacity() {
//        return hours_capacity;
//    }
//    public void setHoursCapacity(int hours_capacity) {
//        this.hours_capacity = hours_capacity;
//    }
//
//    public Long getUserId() {
//        return user_id;
//    }
//    public void setUserId(Long user_id) {
//        this.user_id = user_id;
//    }
//
//    public String getModifiedDate() {
//        return modified_date;
//    }
//    public void setModifiedDate(String modified_date) {
//        this.modified_date = modified_date;
//    }
//
//    public String getModifiedBy() {
//        return modified_by;
//    }
//    public void setModifiedBy(String modified_by) {
//        this.modified_by = modified_by;
//    }
//	public boolean isIs_active() {
//		return is_active;
//	}
//	public void setIs_active(boolean is_active) {
//		this.is_active = is_active;
//	}
}
