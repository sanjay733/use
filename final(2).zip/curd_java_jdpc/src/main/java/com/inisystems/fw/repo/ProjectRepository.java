package com.inisystems.fw.repo;
import com.inisystems.fw.mapper.ProjectRowMapper;

import com.inisystems.fw.mapper.TrackerRowMapper;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.inisystems.fw.mapper.UserRowMapper;
import com.inisystems.fw.model.Project;
import com.inisystems.fw.model.Tracker;
import com.inisystems.fw.model.User;
import com.inisystems.fw.utils.FwUtils;

import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor
public class ProjectRepository {
	
	 private final JdbcTemplate jdbcTemplate;

	    private final NamedParameterJdbcTemplate npJdbcTemplate;
	   
 

	    public void saveProject(Project project) {
	        Timestamp currentTimestamp = FwUtils.getCurrentTimestamp();
	        String insertProjectQuery = "INSERT INTO project (description, name, hours_capacity, user_id, modified_date, modified_by, is_active) " +
	                "VALUES (:description, :name, :hours_capacity, :user_id, :modified_date, :modified_by, :is_active)";

	        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
	        parameterSource.addValue("description", project.getDescription());
	        parameterSource.addValue("name", project.getName());
	        parameterSource.addValue("hours_capacity", project.getHours_capacity());
	        parameterSource.addValue("user_id", project.getUser_id());
	        parameterSource.addValue("modified_date", project.getModified_date());
	        parameterSource.addValue("modified_by", project.getModified_by());
	        parameterSource.addValue("is_active", project.is_active());

	        KeyHolder keyHolder = new GeneratedKeyHolder();

	        npJdbcTemplate.update(insertProjectQuery, parameterSource, keyHolder, new String[]{"id"}); // Specify the name of the generated key column

	        Number generatedId = keyHolder.getKey();

	        if (generatedId != null) {
	            project.setId(generatedId.longValue());
	        }
	    }

	    public List<Project> findProjectsByUserId(Long user_id) {
	        String selectProjectsByUserIdQuery = "SELECT * FROM project WHERE user_id = ?";
	        return jdbcTemplate.query(selectProjectsByUserIdQuery, new ProjectRowMapper(), user_id);
	    }
	    public Project findProjectName(Long projId) {
	        String selectProjectByUserIdQuery = "SELECT * FROM project WHERE id = ?";
	        try {
	            return jdbcTemplate.queryForObject(selectProjectByUserIdQuery, new ProjectRowMapper(), projId);
	        } catch (EmptyResultDataAccessException e) {
	            // Handle the case where no records are found
	            return null;
	        }
	    }
	    
	    public Project findByUserId(Long userId) {
	        String selectProjectByUserIdQuery = "SELECT * FROM project WHERE user_id = ?";
	        try {
	            return jdbcTemplate.queryForObject(selectProjectByUserIdQuery, new ProjectRowMapper(), userId);
	        } catch (EmptyResultDataAccessException e) {
	            // Handle the case where no records are found
	            return null;
	        }
	    }
	}


