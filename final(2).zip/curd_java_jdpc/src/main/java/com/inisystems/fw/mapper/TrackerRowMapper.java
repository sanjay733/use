package com.inisystems.fw.mapper;

import com.inisystems.fw.model.Tracker;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TrackerRowMapper implements RowMapper<Tracker> {

    @Override
    public Tracker mapRow(ResultSet rs, int rowNum) throws SQLException {
        return Tracker.builder()
                .id(rs.getLong("id"))
                .project_id(rs.getLong("project_id"))
                .project_name(rs.getString("project_name"))
                .worked_hours(rs.getInt("worked_hours"))
                .date(rs.getString("date"))
                .user_id(rs.getLong("user_id"))
                .task(rs.getString("task"))
                .isActive(rs.getBoolean("is_active"))
                .comments(rs.getString("comments"))
                .build();
    }
}
