package com.inisystems.fw.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class Tracker {

	private Long id;
	private Long project_id;
	private String project_name;
	private int worked_hours;
    private String date;
	private Long user_id;
    private String task;
    private boolean isActive;
    private String comments;

    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    // Getter and Setter for project_id
    public Long getProjectId() {
        return project_id;
    }
    public void setProjectId(Long project_id) {
        this.project_id = project_id;
    }

    // Getter and Setter for user_id
    public Long getUserId() {
        return user_id;
    }
    public void setUserId(Long user_id) {
        this.user_id = user_id;
    }

    // Getter and Setter for worked_hours
    public int getWorkedHours() {
        return worked_hours;
    }
    public void setWorkedHours(int worked_hours) {
        this.worked_hours = worked_hours;
    }

    public String getProjectName() {
        return project_name;
    }
    public void setProjectName(String project_name) {
        this.project_name = project_name;
    }
    
    // Getter and Setter for date
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    // Getter and Setter for isActive
    public boolean isActive() {
        return isActive;
    }
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    // Getter and Setter for comments
    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }
	public Tracker() {
		// TODO Auto-generated constructor stub
	}
}
