package com.inisystems.fw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inisystems.fw.service.UserService;
@Controller
@RequestMapping("/register")
public class RegisterController {

	  private final UserService userService;
	   
	    
	  
	    @Autowired
	    public RegisterController(UserService userService) {
			super();
			this.userService = userService;
		}


	    @GetMapping("")
	    public String run() {
	    	return "register";
	    }
		@GetMapping("/adduser")
		public String register(@RequestParam(value = "username", required = false) String firstname,
                @RequestParam(value = "password", required = false) String lastname,
                @RequestParam(value = "password", required = false) String email,
                @RequestParam(value = "password", required = false) String password,
                @RequestParam(value = "password", required = false) String confirmPassword) {
			if(!password.equals(confirmPassword)) {
				return"invalid passwords";
			}
			else {
			//	userService.addUser(firstname, lastname, email, password,confirmPassword);
			}
	        return "register";
	    }

	}

