package com.inisystems.fw.controller;



import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.service.UserService;
import com.inisystems.fw.utils.ApiResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

@RequestMapping("/api/secure")
public class SecureController {

    private final UserService userService;

    
    public SecureController(UserService userService) {
		super();
		this.userService = userService;
	}



	@GetMapping("/getalluser")
    public List<User> getAllUsers() {

        return  userService.findAllUsers();
    }



    @PostMapping("/getuser/{email}")
    public ResponseEntity<Object> getUserByUsername(@PathVariable String email) {
        try {
            User user = userService.findByEmail(email);
            return ResponseEntity.ok(user);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
        }
    }


}
