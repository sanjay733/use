package com.inisystems.fw.service;
import com.inisystems.fw.exception.AuthenticationException;
import com.inisystems.fw.exception.UserNotFoundException;
import com.inisystems.fw.model.User;
import com.inisystems.fw.repo.UserRepository;
import com.inisystems.fw.utils.*;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class UserService {
    static Logger LOGGER = LoggerFactory.getLogger("UserService");
    
    @Autowired
    private final UserRepository userRepository;



    public UserService(UserRepository userRepository) {
		//super();
		this.userRepository = userRepository;
	}
    
    

//    public void addUser(String firstName,String lastName,String email,String password) {
//    	User user=new User(null, firstName,lastName,email,password, false);
//    	
//    }
    
    
	public User findByEmail(String email) {
        User user = userRepository.findByEmail(email);

        if (user != null) {
            return user;
        } else {
            throw new UserNotFoundException("User not found with email: " + email);
        }
    }
	
	

    public User authenticateUser(String email, String password) {

        User user = userRepository.findByEmail(email);
       

        if (user != null && password.equals(user.getPassword())) {
            return user;
        } else {
            throw new AuthenticationException("Invalid username or password");
        }
    }
    
    
    public List<User> findAllUsers(){

        return userRepository.findAllUsers();
    }
}

