package com.inisystems.fw.repo;


import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.inisystems.fw.mapper.TrackerRowMapper;
import com.inisystems.fw.model.Tracker;

import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor

public class TrackerRepository {
	
	 private final JdbcTemplate jdbcTemplate;

	    private final NamedParameterJdbcTemplate npJdbcTemplate;

	   

	    

	    public void saveTracker(Tracker tracker) {
	        String insertTrackerQuery = "INSERT INTO tracker (project_id, project_name, worked_hours, date, user_id, task, is_active, comments) " +
	                "VALUES (:project_id, :project_name, :worked_hours, :date, :user_id, :task, :is_active, :comments)";

	        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
	        parameterSource.addValue("project_id", tracker.getProject_id());
	        parameterSource.addValue("project_name", tracker.getProject_name());
	        parameterSource.addValue("worked_hours", tracker.getWorked_hours());
	        parameterSource.addValue("date", tracker.getDate());
	        parameterSource.addValue("user_id", tracker.getUser_id());
	        parameterSource.addValue("task", tracker.getTask());
	        parameterSource.addValue("is_active", tracker.isActive()); // assuming that 'isActive()' returns a boolean
	        parameterSource.addValue("comments", tracker.getComments());

	        KeyHolder keyHolder = new GeneratedKeyHolder();

	        npJdbcTemplate.update(insertTrackerQuery, parameterSource, keyHolder, new String[]{"id"});

	        Number generatedId = keyHolder.getKey();

	        if (generatedId != null) {
	            tracker.setId(generatedId.longValue());
	        }
	    }
	    
	    public void updateTracker(Tracker tracker) {
	        String updateTrackerQuery = "UPDATE tracker SET worked_hours = :worked_hours, date = :date, " +
	                "comments = :comments WHERE id = :id";

	        MapSqlParameterSource parameterSource = new MapSqlParameterSource()
	                .addValue("id", tracker.getId())
	                .addValue("worked_hours", tracker.getWorked_hours())
	                .addValue("date", tracker.getDate())
	                .addValue("comments", tracker.getComments());

	        npJdbcTemplate.update(updateTrackerQuery, parameterSource);
	    }


	    public void deleteTracker(Long id) {
	        String deleteTrackerQuery = "DELETE FROM tracker WHERE id = ?";
	        jdbcTemplate.update(deleteTrackerQuery, id);
	    }
	    

	    public List<Tracker> findAllWorks(Long userId) {
	        String selectWorksByUserIdQuery = "SELECT * FROM tracker WHERE user_id = ?";
	        return jdbcTemplate.query(selectWorksByUserIdQuery, new TrackerRowMapper(), userId);
	    }
	    ;
	    public List<Tracker> findWeekly(Long userId){
	        String weeklyDate = "SELECT *, curdate() FROM tracker t WHERE user_id = ? AND date BETWEEN CURDATE() - INTERVAL 6 DAY AND CURDATE();";
	        return jdbcTemplate.query(weeklyDate,new TrackerRowMapper(), userId);
	    }
	    public List<Tracker> findMonthly(Long userId){
	        String monthlyDate="SELECT *, curdate() FROM tracker t WHERE user_id = ? AND date BETWEEN CURDATE() - INTERVAL 1 MONTH AND CURDATE();";
	        return jdbcTemplate.query(monthlyDate,new TrackerRowMapper(), userId);
	    }
	}

