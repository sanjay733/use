package com.inisystems.fw.controller;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inisystems.fw.model.Project;
import com.inisystems.fw.model.User;
import com.inisystems.fw.model.Tracker;

import com.inisystems.fw.service.ProjectService;
import com.inisystems.fw.service.TrackerService;
import com.inisystems.fw.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/secure/tracker")
public class TimeTrackController {
	
     @Autowired		 
	private final UserService userService;
     @Autowired	
    private final ProjectService projectService;
     @Autowired	
    private final TrackerService trackerService;
   
  
    public TimeTrackController(UserService userService, ProjectService projectService,TrackerService trackerService) {
        this.userService = userService;
        this.trackerService=trackerService;
        this.projectService = projectService;
    }
    
    private User  getUser(String email) {
    	User user=userService.findByEmail(email);
    return user;
    }


    @GetMapping()
    public String ss() {
       return "tracker";
    }
    
    @PostMapping("/saveWork")
    public ResponseEntity<?> saveWork(@RequestBody Map<String, Object> requestBody,HttpServletRequest req) {
		   String email=(String)req.getAttribute("email");
		 User user=getUser(email);
    	 String projectIdNumber = requestBody.get("projectId").toString();
    	    Long project_id = Long.parseLong(projectIdNumber);  
    	  //  String project_name = requestBody.get("projectName").toString();
        String date = requestBody.get("date").toString();
        String task = requestBody.get("taskDropdown").toString();
 	   String hours_worked=requestBody.get("hoursWorked").toString();
	   int hours_capacity=Integer.parseInt(hours_worked);     
	   String comments = requestBody.get("comments").toString();
	   
	   
	   Project project_=projectService.getProjectName(project_id);
	   System.out.println(project_);
        try {
            trackerService.saveWork(project_id,  project_.getName(),  hours_capacity,  date,  user.getId(),  task,  comments );
            return ResponseEntity.ok("User saved successfully");
           
        }
         catch (Exception e) {
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
        }
    }
    
    
    @PutMapping("/updateWork")
    public ResponseEntity<?> updateWork(@RequestBody Map<String, Object> requestBody, HttpServletRequest req) {
        String email = (String) req.getAttribute("email");
        // User user = getUser(email);

        String updateDate = requestBody.get("date").toString();
        String updateComments = requestBody.get("comments").toString();

        // Parse hoursWorked as Integer
        Integer updateHoursWorked = Integer.parseInt(requestBody.get("hoursWorked").toString());

        Long updateTrackerId = Long.parseLong(requestBody.get("trackerId").toString());

        try {
            trackerService.updateWork(updateTrackerId, updateDate, updateHoursWorked, updateComments);
            return ResponseEntity.ok("Work updated successfully");
        } catch (Exception e) {
            // Log the exception for further investigation
            e.printStackTrace();  // You can replace this with your logging framework
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
        }
    }


    @DeleteMapping("/deleteWork")
    public ResponseEntity<?> deleteWork(@RequestBody Map<String, Object> requestBody,HttpServletRequest req) {
        Object idObject = requestBody.get("id");
		   String email=(String)req.getAttribute("email");
        if (idObject instanceof Number) {
            Long deleteWorkId = ((Number) idObject).longValue();

            try {
                trackerService.deleteWork(deleteWorkId);
                return ResponseEntity.ok("Work deleted successfully");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred");
            }
        } else {
            return ResponseEntity.badRequest().body("Invalid ID format");
        }
    }

  
    @PostMapping("/submit")
    public ResponseEntity<?> submitButtonPressed(@RequestBody Map<String, Object> requestBody) {
        Object idObject = requestBody.get("id");

        if (idObject instanceof Number) {
            Long trackerId = ((Number) idObject).longValue();
            try {
                trackerService.updateTrackerStatus(trackerId, false);
                return ResponseEntity.ok("Tracker status updated successfully");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR)
                        .body("An unexpected error occurred while updating tracker status");
            }
        } else {
            return ResponseEntity.badRequest().body("Invalid ID format");
        }
    }
    
    @GetMapping("/view/weekly")
    public ResponseEntity<?> getWeekly(HttpServletRequest req){
    	
		 String email=(String)req.getAttribute("email");
		 User user=getUser(email);
        List<Tracker> trackerList=trackerService.findWeekly(user);
        return ResponseEntity.ok().body(trackerList);
    }
    
    @GetMapping("/view/monthly")
    public ResponseEntity<?> getMonthly(HttpServletRequest req){
    	 String email=(String)req.getAttribute("email");
		 User user=getUser(email);
        List<Tracker> trackerList=trackerService.findMonthly(user);
        return ResponseEntity.ok().body(trackerList);
    }
    
   @GetMapping("/getWork")
    	public ResponseEntity<?> getWorkList(HttpServletRequest req) {
	   String email=(String)req.getAttribute("email");
		 User user=getUser(email);
    	       List<Tracker> trackerList=trackerService.findAllWorks(user);
    	        return ResponseEntity.ok().body(trackerList);
    	    
    }
    
}
   